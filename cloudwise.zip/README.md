# CloudWise – Intelligent Cloud Cost Optimizer (MVP)

> A simple full-stack cloud resource management application built with **Spring Boot 3 + Angular 18**.
> Designed for final-year Computer Science students as a realistic portfolio / resume project.

---

## Project Overview

**CloudWise** is a learning-focused web application that simulates cloud resource
management. It does **not** connect to AWS, Azure, or Google Cloud – instead, it
uses sample data stored in an **H2 in-memory database** so you can run the entire
project locally without any cloud account, API keys, or Docker.

Users can:

- View all cloud resources in a clean dashboard
- Add, edit, and delete cloud resources
- See live cost statistics (Total / Running / Stopped / Total Monthly Cost)
- Get an automatic cost recommendation for every resource:
  - **Monthly Cost > ₹5,000 → "High Cost Resource"**
  - **Otherwise → "Normal Resource"**

The recommendation is generated automatically by the backend – the user never
types it in. This demonstrates a small piece of "business logic" without any
advanced patterns.

---

## Features

- Clean, simple, beginner-friendly codebase
- Full CRUD REST API built with Spring Boot 3
- Responsive Angular 18 UI with white background, blue header, and simple cards
- H2 in-memory database with auto-created tables and 10 sample resources seeded on startup
- H2 Console enabled for easy database inspection
- Global exception handler that returns clean JSON error responses
- Bean Validation on the request DTO (`@NotBlank`, `@PositiveOrZero`, etc.)
- Constructor-based dependency injection throughout (recommended by Spring)
- Automatic recommendation generation
- Cross-origin (CORS) configured so the Angular dev server can call the backend
- Standard HTTP status codes: `200 OK`, `201 Created`, `204 No Content`, `404 Not Found`, `400 Bad Request`, `500 Internal Server Error`

---

## Technology Stack

### Backend
| Technology        | Purpose                              |
|-------------------|--------------------------------------|
| Java 21           | Programming language                 |
| Spring Boot 3.3   | Application framework                |
| Spring Data JPA   | Database access (Hibernate)          |
| Spring Web        | REST API controllers                 |
| Spring Validation | Bean validation (`@Valid`)           |
| H2 Database       | In-memory database                   |
| Maven             | Build tool                           |

### Frontend
| Technology        | Purpose                              |
|-------------------|--------------------------------------|
| Angular 18        | SPA framework                        |
| TypeScript 5.5    | Type-safe JavaScript                 |
| Standalone components | Modern Angular pattern           |
| RxJS              | Reactive HTTP calls                  |
| CSS               | Plain CSS for simple styling         |

### Development Tools
- IntelliJ IDEA Community (backend)
- VS Code (frontend)
- Git & GitHub
- H2 Console (in-browser DB viewer)

---

## Folder Structure

```
cloudwise/
├── README.md
├── backend/                          # Spring Boot application
│   ├── pom.xml
│   ├── mvnw / mvnw.cmd               # Maven Wrapper (no need to install Maven)
│   ├── .mvn/wrapper/
│   └── src/
│       ├── main/
│       │   ├── java/com/cloudwise/
│       │   │   ├── CloudWiseApplication.java    # Main class
│       │   │   ├── controller/
│       │   │   │   └── CloudResourceController.java
│       │   │   ├── service/
│       │   │   │   └── CloudResourceService.java
│       │   │   ├── repository/
│       │   │   │   └── CloudResourceRepository.java
│       │   │   ├── entity/
│       │   │   │   └── CloudResource.java
│       │   │   ├── dto/
│       │   │   │   ├── CloudResourceRequest.java
│       │   │   │   ├── CloudResourceResponse.java
│       │   │   │   └── DashboardResponse.java
│       │   │   ├── config/
│       │   │   │   └── DataInitializer.java     # Seeds 10 sample resources
│       │   │   └── exception/
│       │   │       ├── ResourceNotFoundException.java
│       │   │       ├── GlobalExceptionHandler.java
│       │   │       └── ErrorResponse.java
│       │   └── resources/
│       │       └── application.properties
│       └── test/
│           └── java/com/cloudwise/
│               └── CloudWiseApplicationTests.java
│
└── frontend/                         # Angular 18 application
    ├── package.json
    ├── angular.json
    ├── tsconfig.json
    ├── tsconfig.app.json
    ├── tsconfig.spec.json
    └── src/
        ├── index.html
        ├── main.ts
        ├── styles.css                # Global styles
        ├── assets/
        │   └── favicon.svg
        ├── environments/
        │   ├── environment.ts
        │   └── environment.development.ts
        └── app/
            ├── app.component.ts/html/css   # Root + navigation header
            ├── app.config.ts
            ├── app.routes.ts
            ├── dashboard/
            │   ├── dashboard.component.ts/html/css
            ├── resources/
            │   ├── resources.component.ts/html/css
            ├── add-resource/
            │   ├── add-resource.component.ts/html/css
            ├── edit-resource/
            │   ├── edit-resource.component.ts/html/css
            ├── services/
            │   └── cloud-resource.service.ts
            ├── models/
            │   └── cloud-resource.model.ts
            └── shared/
                └── status-badge.component.ts
```

---

## Prerequisites

Make sure the following are installed on your machine:

| Tool            | Minimum Version | Verify with          |
|-----------------|-----------------|----------------------|
| Java JDK        | 21              | `java -version`      |
| Maven           | 3.9+ (optional) | `mvn -version`       |
| Node.js         | 18 LTS or 20 LTS | `node -v`           |
| npm             | 9+              | `npm -v`             |
| Angular CLI     | 18              | `ng version`         |

> **Note about Maven:** The backend includes the Maven Wrapper (`mvnw`), so you
> do **not** need to install Maven yourself. Just use `./mvnw` (Mac/Linux) or
> `mvnw.cmd` (Windows) instead of `mvn`.

> **Important:** Make sure you install a full **JDK 21**, not just a JRE. The
> JDK includes the `javac` compiler, which Maven needs to compile the Java code.

---

## Installation Steps

### 1. Clone the repository
```bash
git clone https://github.com/<your-username>/cloudwise.git
cd cloudwise
```

### 2. Run the Backend (Spring Boot)

Open a terminal in the `backend/` folder:

```bash
cd backend

# Option A: Using the Maven Wrapper (recommended - no Maven install needed)
./mvnw spring-boot:run            # Mac / Linux
mvnw.cmd spring-boot:run          # Windows

# Option B: If you have Maven installed globally
mvn spring-boot:run
```

The backend will start on **http://localhost:8080**.

You should see a line like this in the console:
```
==> CloudWise: 10 sample cloud resources inserted into the database.
```

### 3. Run the Frontend (Angular)

Open **another terminal** in the `frontend/` folder:

```bash
cd frontend

# Install dependencies (only needed the first time)
npm install

# Start the dev server
npm start
# Or equivalently: ng serve
```

The frontend will start on **http://localhost:4200**.

Open your browser and navigate to **http://localhost:4200** – you should see the
CloudWise dashboard with 10 sample resources already loaded.

---

## H2 Console Access

The H2 in-memory database comes with a built-in web console. To access it:

1. Make sure the backend is running.
2. Open **http://localhost:8080/h2-console** in your browser.
3. Use these connection settings:

| Field        | Value                    |
|--------------|--------------------------|
| JDBC URL     | `jdbc:h2:mem:cloudwise`  |
| User Name    | `sa`                     |
| Password     | *(leave empty)*          |

4. Click **Connect**.
5. You can now run SQL queries against the `cloud_resource` table, for example:
   ```sql
   SELECT * FROM cloud_resource;
   ```

> **Note:** Because the database is in-memory, all data is lost when you restart
> the backend. The 10 sample resources are re-inserted automatically on every
> startup by the `DataInitializer` class.

---

## REST API Endpoints

Base URL: `http://localhost:8080/api`

| Method   | Endpoint           | Description                        | Status Codes           |
|----------|--------------------|------------------------------------|------------------------|
| `GET`    | `/resources`       | Get all cloud resources            | 200                    |
| `GET`    | `/resources/{id}`  | Get a single resource by id        | 200, 404               |
| `POST`   | `/resources`       | Create a new resource              | 201, 400               |
| `PUT`    | `/resources/{id}`  | Update an existing resource        | 200, 404, 400          |
| `DELETE` | `/resources/{id}`  | Delete a resource                  | 204, 404               |
| `GET`    | `/dashboard`       | Get aggregated dashboard stats     | 200                    |

### Example Requests (using curl)

```bash
# Get all resources
curl http://localhost:8080/api/resources

# Get dashboard statistics
curl http://localhost:8080/api/dashboard

# Get a single resource by id
curl http://localhost:8080/api/resources/1

# Create a new resource
curl -X POST http://localhost:8080/api/resources \
  -H "Content-Type: application/json" \
  -d '{
    "resourceName": "EC2 Test Server",
    "resourceType": "EC2",
    "region": "Mumbai",
    "status": "Running",
    "monthlyCost": 6000
  }'

# Update an existing resource
curl -X PUT http://localhost:8080/api/resources/1 \
  -H "Content-Type: application/json" \
  -d '{
    "resourceName": "EC2 Web Server - Updated",
    "resourceType": "EC2",
    "region": "Mumbai",
    "status": "Running",
    "monthlyCost": 4800
  }'

# Delete a resource
curl -X DELETE http://localhost:8080/api/resources/1
```

### Example Error Response

When a resource is not found, the API returns a structured JSON error:

```json
{
  "timestamp": "2026-07-27T10:00:00",
  "status": 404,
  "message": "Resource not found with id: 99"
}
```

### Example Dashboard Response

```json
{
  "totalResources": 10,
  "runningResources": 8,
  "stoppedResources": 2,
  "totalMonthlyCost": 36100.0
}
```

---

## Sample Data

The following 10 cloud resources are inserted automatically when the backend
starts (see `DataInitializer.java`):

| # | Resource Name              | Type   | Region | Status   | Monthly Cost (₹) | Recommendation        |
|---|----------------------------|--------|--------|----------|------------------|-----------------------|
| 1 | EC2 Web Server             | EC2    | Mumbai | Running  | 4500             | Normal Resource       |
| 2 | EC2 Database Server        | EC2    | Mumbai | Running  | 8500             | High Cost Resource    |
| 3 | EC2 Development Server     | EC2    | Delhi  | Stopped  | 2500             | Normal Resource       |
| 4 | S3 Backup Bucket           | S3     | Mumbai | Running  | 900              | Normal Resource       |
| 5 | S3 Logs Bucket             | S3     | Delhi  | Running  | 700              | Normal Resource       |
| 6 | RDS Production Database    | RDS    | Mumbai | Running  | 12000            | High Cost Resource    |
| 7 | RDS Testing Database       | RDS    | Delhi  | Stopped  | 3200             | Normal Resource       |
| 8 | Elastic Load Balancer      | ELB    | Mumbai | Running  | 2800             | Normal Resource       |
| 9 | EBS Volume                 | EBS    | Mumbai | Running  | 600              | Normal Resource       |
| 10| Lambda Function            | Lambda | Delhi  | Running  | 400              | Normal Resource       |

---

## Sample Screenshots

> After running the project, take screenshots of the following pages and add
> them to a `screenshots/` folder in the repository root. Then update the links
> below.

1. **Dashboard** – `screenshots/dashboard.png`
2. **Resources List** – `screenshots/resources.png`
3. **Add Resource Form** – `screenshots/add-resource.png`
4. **Edit Resource Form** – `screenshots/edit-resource.png`
5. **H2 Console** – `screenshots/h2-console.png`

```markdown
![Dashboard](screenshots/dashboard.png)
![Resources](screenshots/resources.png)
![Add Resource](screenshots/add-resource.png)
![Edit Resource](screenshots/edit-resource.png)
![H2 Console](screenshots/h2-console.png)
```

---

## Recommendation Logic

The recommendation engine is intentionally simple to keep the project easy to
explain in interviews:

```java
// In CloudResource.java
public void generateRecommendation() {
    if (this.monthlyCost != null && this.monthlyCost > 5000) {
        this.recommendation = "High Cost Resource";
    } else {
        this.recommendation = "Normal Resource";
    }
}
```

This method is called by the service layer **before** saving or updating a
resource. The user never sends the recommendation in the request – it is always
derived from the monthly cost.

---

## Code Style

This project follows beginner-friendly conventions:

- ✅ Constructor-based dependency injection (no `@Autowired` on fields)
- ✅ Small, focused service methods (one responsibility each)
- ✅ DTOs to separate API contract from database entity
- ✅ Meaningful class, method, and variable names
- ✅ Comments only where they add value
- ✅ Standard Spring Boot folder structure
- ✅ No advanced enterprise patterns (no factories, no strategy pattern, no AOP)
- ✅ No Lombok – all getters/setters are written explicitly so beginners can
  see exactly what is happening

---

## Troubleshooting

### "release version 21 not supported"
You are using an older JDK. Install **JDK 21** (not just JRE 21) and make sure
`JAVA_HOME` points to it. Verify with `java -version` and `javac -version`.

### Frontend cannot connect to backend
Make sure the backend is running on port 8080. Check the browser console for
CORS errors. The backend already allows `http://localhost:4200` via
`@CrossOrigin`.

### H2 Console shows "database is empty"
This is normal on first load – the `DataInitializer` only seeds data on
application startup. Restart the backend if needed.

### Port 8080 or 4200 already in use
- Backend: change `server.port` in `application.properties`.
- Frontend: run `ng serve --port 4201`.

---

## Future Improvements

These are intentionally **not implemented** – they are listed as future work:

- MySQL Support (replace H2 with a persistent database)
- AWS Integration (real cloud resource fetching)
- Azure Integration
- GCP Integration
- Authentication (Spring Security + JWT)
- Docker containerization
- Kubernetes deployment manifests
- Charts and graphs (e.g. Chart.js or Angular Material Charts)
- Email alerts when a resource is flagged as "High Cost"

---

## License

This project is intended for **learning and portfolio purposes only**.
Feel free to use it as a starting point for your own resume projects.

---

## Author

**Your Name** – Final Year Computer Science Student

> Replace this section with your own details, GitHub link, and LinkedIn profile
> before uploading to GitHub.
